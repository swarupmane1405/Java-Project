import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;

public class Dashboard {
 public Dashboard(String k){
  JFrame F = new JFrame("Dashboard");
  // ImageIcon img = new ImageIcon("Employee.png");
  ImageIcon img = new ImageIcon("Company.png");
  JLabel back = new JLabel("", img, JLabel.CENTER);
  back.setBounds(0, 0, 1200, 650);
  F.setSize(1200, 650);
  F.add(back);

  F.setVisible(true);
  F.setResizable(false);
  F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


  JButton b1 = new JButton("DASHBOARD");
  JButton b2 = new JButton("OPENINGS");
  JButton b3 = new JButton("APPLY");
  JButton b4 = new JButton("MY PROFILE");
  b1.setFont(new Font("Poppins", Font.BOLD, 20));
  b2.setFont(new Font("Poppins", Font.BOLD, 20));
  b3.setFont(new Font("Poppins", Font.BOLD, 20));
  b4.setFont(new Font("Poppins", Font.BOLD, 20));

  b1.setBounds(70, 165, 200, 50);
  back.add(b1);
  b1.setContentAreaFilled(false);
  b1.setBorderPainted(false);
  b1.setForeground(Color.WHITE);

  b2.setBounds(70, 265, 200, 50);
  back.add(b2);
  b2.setContentAreaFilled(false);
  b2.setBorderPainted(false);
  b2.setForeground(Color.WHITE);

  b4.setBounds(70, 465, 200, 50);
  back.add(b4);
  b4.setContentAreaFilled(false);
  b4.setBorderPainted(false);
  b4.setForeground(Color.WHITE);

  b3.setBounds(70, 365, 200, 50);
  back.add(b3);
  b3.setContentAreaFilled(false);
  b3.setBorderPainted(false);
  b3.setForeground(Color.WHITE);

  // dashboard part
  JLabel no_s = new JLabel("Total Students");
  JLabel no_c = new JLabel("Total Companies");
  JLabel no_w = new JLabel("Programs");
  no_s.setFont(new Font("Poppins", Font.BOLD, 20));
  no_c.setFont(new Font("Poppins", Font.BOLD, 20));
  no_w.setFont(new Font("Poppins", Font.BOLD, 20));

  Color my = new Color(200, 0, 0);
  no_s.setForeground(my);
  no_c.setForeground(my);
  no_w.setForeground(my);
  back.add(no_s);
  back.add(no_c);
  back.add(no_w);

  no_s.setBounds(460, 185, 200, 50);
  no_c.setBounds(680, 185, 200, 50);
  no_w.setBounds(960, 185, 200, 50);

  JPanel panel1 = new JPanel();
  panel1.setBackground(Color.white);
  panel1.setBounds(350, 0, 850, 650);
  back.add(panel1);
  panel1.setLayout(null);
  panel1.setVisible(false);


  JPanel panel2 = new JPanel();
  panel2.setBackground(Color.PINK);
  panel2.setBounds(343, 0, 850, 650);


  JPanel panel3 = new JPanel();
  panel3.setBackground(Color.pink);
  panel3.setBounds(343, 0, 850, 650);
  back.add(panel3);
  panel3.setVisible(false);
  panel3.setLayout(null);

  JPanel panelM = new JPanel();
  panelM.setBounds(343, 0, 850, 650);
  back.add(panelM);
  panelM.setOpaque(false);
  panelM.setVisible(true);
  panelM.setLayout(null);

// openings

   String[] columnNames = null;

  Object[][] data = null;

  try{
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdproject", "root", "scm@1405");
   PreparedStatement ps=con.prepareStatement("select Vaccancy_ID,Comp_name,Dept_name,Domain,Location,Openings from company_info;",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
   ResultSet rs=ps.executeQuery();
   ResultSetMetaData rsmd=rs.getMetaData();
   int cols=rsmd.getColumnCount();
   columnNames=new String[cols];
   for(int i=1;i<=cols;i++){
    columnNames[i-1]=rsmd.getColumnName(i);
   }
   rs.last();
   int rows=rs.getRow();
   rs.beforeFirst();

   data=new String[rows][cols];
   int count=0;
   while(rs.next()){
    for(int i=1;i<=cols;i++){
     data[count][i-1]=rs.getString(i);
    }
    count++;
   }
   con.close();
  }catch(Exception e){System.out.println(e);}



  DefaultTableModel model=new DefaultTableModel(data, columnNames);
  JTable table = new JTable(model);
  table.getColumnModel().getColumn(0).setPreferredWidth(50);
  table.getColumnModel().getColumn(1).setPreferredWidth(100);
  table.getColumnModel().getColumn(2).setPreferredWidth(120);
  table.getColumnModel().getColumn(3).setPreferredWidth(100);
  table.getColumnModel().getColumn(4).setPreferredWidth(120);

  DefaultTableCellRenderer Cell = new DefaultTableCellRenderer();
 Cell.setHorizontalAlignment(JLabel.CENTER);
  for (int i =0; i<6; i++){
  table.getColumnModel().getColumn(i).setCellRenderer(Cell);
  }


  JScrollPane scrollPane = new JScrollPane(table);
  scrollPane.setViewportView(table);
  table.getColumnModel().getColumn(0).setPreferredWidth(200);
  scrollPane.setBounds(20,20,800,500);
  panel1.add(scrollPane);
/*
  JLabel lbl1 = new JLabel("Department Name : ");
  lbl1.setVisible(true);
  panel1.add(lbl1);
  String[] choices1 = { "CHOICE 1","CHOICE 2", "CHOICE 3","CHOICE 4","CHOICE 5","CHOICE 6"};
  final JComboBox<String> cb1 = new JComboBox<String>(choices1);
  cb1.setVisible(true);
  cb1.setBounds(50, 600, 100,100);
  panel1.add(cb1);

  JLabel lbl2 = new JLabel("Location : ");
  lbl2.setVisible(true);
  panel1.add(lbl2);

  String[] choices2 = { "Karad","CHOICE 2", "CHOICE 3","CHOICE 4","CHOICE 5","CHOICE 6"};
  final JComboBox<String> cb2 = new JComboBox<String>(choices2);
  cb2.setVisible(true);
  cb2.setBounds(50, 600, 100,100);
  panel1.add(cb2);

  JLabel lbl3 = new JLabel("Requriments : ");
  lbl1.setVisible(true);
  panel1.add(lbl3);

  String[] choices3 = { "choice 1","Tester", "CHOICE 3","CHOICE 4","CHOICE 5","CHOICE 6"};
  final JComboBox<String> cb3 = new JComboBox<String>(choices3);
  cb3.setVisible(true);
  cb3.setBounds(100, 600, 100,100);
  panel1.add(cb3);
*/
  JTextField searchbar=new JTextField();
  searchbar.setBounds(250, 550, 200,50);
  panel1.add(searchbar);
  JButton selectbtn = new JButton("OK");
  panel1.add(selectbtn);
  selectbtn.setBackground(my);
  selectbtn.setBorder(javax.swing.BorderFactory.createEmptyBorder());
  selectbtn.setBounds(500,550,100,50);
  selectbtn.setForeground(Color.WHITE);
  selectbtn.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
    String query = searchbar.getText();
    TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(model);
    table.setRowSorter(tr);
    if (query != null){
     tr.setRowFilter(RowFilter.regexFilter(query));
    }else{
     table.setRowSorter(tr);
    }
   }
  });

  // Dashboard
   JLabel nos = new JLabel();
   nos.setBounds(140,20,100,200);
   nos.setFont(new Font("Poppins", Font.BOLD, 80));
   nos.setForeground(my);
   nos.setText("50");
   panelM.add(nos);

   JLabel noc = new JLabel();
   noc.setBounds(370,20,100,200);
   noc.setFont(new Font("Poppins", Font.BOLD, 80));
   noc.setForeground(my);
   noc.setText("10");
   panelM.add(noc);

  JLabel noj = new JLabel();
  noj.setBounds(610,20,100,200);
  noj.setFont(new Font("Poppins", Font.BOLD, 80));
  noj.setForeground(my);
  noj.setText("06");
  panelM.add(noj);



  JLabel name = new JLabel("<html>Students Hiring System <br><br> This system is for both Student and Companies.<br> The students can apply for the job depending upon their area of expertise and also companies can display the various opening for different domains and also can aprove the proposal from the students.</html>");
  name.setBounds(120,350,650,200);
  panelM.add(name);
  name.setFont(new Font("Poppins", Font.PLAIN, 20));
  name.setForeground(my);

//apply
panel2.setLayout(null);
JLabel Department = new JLabel("Enter Department : ");
JLabel AppliedCompany = new JLabel("Enter Applied Company : ");
JLabel Domain = new JLabel("Enter Domain : ");
JLabel Project = new JLabel("Enter no of Projects : ");



Department.setFont(new Font("Poppins", Font.PLAIN, 20));
AppliedCompany.setFont(new Font("Poppins", Font.PLAIN, 20));
Domain.setFont(new Font("Poppins", Font.PLAIN, 20));
Project.setFont(new Font("Poppins", Font.PLAIN, 20));



Department.setBounds(50,150,300,50);
AppliedCompany.setBounds(50,230,300,50);
Domain.setBounds(50,320,300,50);
Project.setBounds(50,400,300,50);


  JTextField Department1 = new JTextField("   Enter Department");
  JTextField AppliedCompany1 = new JTextField("  Enter Applied Company");
  JTextField Domain1 = new JTextField("  Enter Domain");
  JTextField Project1 = new JTextField("  Enter no of Projects");


  Department1.setBounds(350,150,400,50);
  AppliedCompany1.setBounds(350,230,400,50);
  Domain1.setBounds(350,320,400,50);
  Project1.setBounds(350,400,400,50);



  Department1.setFont(new Font("Poppins", Font.PLAIN, 20));
  AppliedCompany1.setFont(new Font("Poppins", Font.PLAIN, 20));
  Domain1.setFont(new Font("Poppins", Font.PLAIN, 20));
  Project1.setFont(new Font("Poppins", Font.PLAIN, 20));


  Department1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
  AppliedCompany1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
  Domain1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
  Project1.setBorder(javax.swing.BorderFactory.createEmptyBorder());



  panel2.add(Department);
  panel2.add(Domain);
  panel2.add(AppliedCompany);
  panel2.add(Project);


  panel2.add(Department1);
  panel2.add(Domain1);
  panel2.add(AppliedCompany1);
  panel2.add(Project1);

  JButton Apply = new JButton("Apply");
  Apply.setFont(new Font("Poppins", Font.PLAIN, 20));
  Apply.setBackground(my);
  Apply.setBorder(javax.swing.BorderFactory.createEmptyBorder());
  Apply.setForeground(Color.WHITE);
  Apply.setBounds(350,500,200,50);
  panel2.add(Apply);

  //connectivity

  final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
  final String USERNAME = "root";
  final String PASSWORD = "scm@1405";

  Apply.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {

    String UserID2 = k;
    String Department2 = Department1.getText();
    String AppliedCompany2 = AppliedCompany1.getText();
    String Domain2 =Domain1.getText();
    String Project2 = Project1.getText();


    try{
     Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);

     Statement stmt = conn.createStatement();
     String sql = "INSERT INTO studhireinfo(UserId,Department,Applied_comp,Domain,No_Project_Complete)"+"VALUES(?,?,?,?,?)";

     PreparedStatement preparedStatement = conn.prepareStatement(sql);
     preparedStatement.setString(1,UserID2);
     preparedStatement.setString(2,Department2);
     preparedStatement.setString(3,AppliedCompany2);
     preparedStatement.setString(4,Domain2);
     preparedStatement.setString(5,Project2);

     preparedStatement.executeUpdate();

     stmt.close();
     conn.close();

    }catch (Exception z){
     z.printStackTrace();
    }

   }
  });

  // my profile
JLabel Myuser = new JLabel();
  JLabel Studname = new JLabel();
  JLabel Gender = new JLabel();
  JLabel dept = new JLabel();
  JLabel Institute = new JLabel();

  try{
   Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
   Statement stmt = conn.createStatement();
   ResultSet rs = stmt.executeQuery("select * from studperinfo where UserID='"+k+"'");
   while(rs.next()){
    Myuser.setText("UserID : "+rs.getString("UserID"));
    Studname.setText("Student Name : "+rs.getString("Stud_name"));
    Gender.setText("Gender : "+rs.getString("Gender"));
    dept.setText("Department : "+rs.getString("Department"));
    Institute.setText("Institute : "+rs.getString("InstituteName"));
   }
stmt.close();
  conn.close();

 }catch (Exception z){
  z.printStackTrace();
 }

  Myuser.setBounds(350,70,400,50);
  Studname.setBounds(350,130,400,50);
  Gender.setBounds(350,190,400,50);
  dept.setBounds(350,250,400,50);
  Institute.setBounds(350,310,400,50);

  Myuser.setFont(new Font("Poppins", Font.PLAIN, 20));
  Studname.setFont(new Font("Poppins", Font.PLAIN, 20));
  Gender.setFont(new Font("Poppins", Font.PLAIN, 20));
  dept.setFont(new Font("Poppins", Font.PLAIN, 20));
  Institute.setFont(new Font("Poppins", Font.PLAIN, 20));

  panel3.add(Myuser);
  panel3.add(Studname);
  panel3.add(Gender);
  panel3.add(dept);
  panel3.add(Institute);

  ImageIcon profile = new ImageIcon("profilew.png");
  JLabel profilelabel = new JLabel("",profile,JLabel.CENTER);
  profilelabel.setBounds(80,100,200,200);
  panel3.add(profilelabel);


  String[] columnNames1 = null;

  Object[][] data1 = null;

  try{
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdproject", "root", "scm@1405");
   PreparedStatement ps=con.prepareStatement("select Applied_ID,Applied_comp,Approved,Domain,Department,Current_comp from studhireinfo where UserID='"+k+"'",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
   ResultSet rs=ps.executeQuery();
   ResultSetMetaData rsmd=rs.getMetaData();
   int cols=rsmd.getColumnCount();
   columnNames1=new String[cols];
   for(int i=1;i<=cols;i++){
    columnNames1[i-1]=rsmd.getColumnName(i);
   }
   rs.last();
   int rows=rs.getRow();
   rs.beforeFirst();

   data1=new String[rows][cols];
   int count=0;
   while(rs.next()){
    for(int i=1;i<=cols;i++){
     data1[count][i-1]=rs.getString(i);
    }
    count++;
   }
   con.close();
  }catch(Exception e){System.out.println(e);}


  JTable table1 = new JTable(data1, columnNames1);

  table1.getColumnModel().getColumn(0).setPreferredWidth(50);
  table1.getColumnModel().getColumn(1).setPreferredWidth(100);
  table1.getColumnModel().getColumn(2).setPreferredWidth(120);
  table1.getColumnModel().getColumn(3).setPreferredWidth(100);
  table1.getColumnModel().getColumn(4).setPreferredWidth(120);
  table1.getColumnModel().getColumn(5).setPreferredWidth(120);


  DefaultTableCellRenderer Cell1 = new DefaultTableCellRenderer();
  Cell1.setHorizontalAlignment(JLabel.CENTER);
  for (int i =0; i<6; i++){
   table1.getColumnModel().getColumn(i).setCellRenderer(Cell1);
  }


  JScrollPane scrollPane1 = new JScrollPane(table1);
  scrollPane1.setViewportView(table1);
  table1.getColumnModel().getColumn(0).setPreferredWidth(200);
  scrollPane1.setBounds(20,380,800,200);
  panel3.add(scrollPane1);



//final buttons
  back.add(panel2);
  panel2.setVisible(false);
  panel2.setLayout(null);
  b2.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
    panel1.setVisible(true);
    no_c.setVisible(false);
    no_s.setVisible(false);
    no_w.setVisible(false);
    panel2.setVisible(false);
    panel3.setVisible(false);
    panelM.setVisible(false);
   }
  });
  b1.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
    panel1.setVisible(false);
    no_c.setVisible(true);
    no_s.setVisible(true);
    no_w.setVisible(true);
    panel2.setVisible(false);
    panel3.setVisible(false);
    panelM.setVisible(true);
   }
  });

  b3.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
    panel2.setVisible(true);
    no_c.setVisible(false);
    no_s.setVisible(false);
    no_w.setVisible(false);
    panel1.setVisible(false);
    panel3.setVisible(false);
    panelM.setVisible(false);
   }
  });

  b4.addActionListener(new ActionListener() {
   @Override
   public void actionPerformed(ActionEvent e) {
    panel2.setVisible(false);
    no_c.setVisible(false);
    no_s.setVisible(false);
    no_w.setVisible(false);
    panel1.setVisible(false);
    panel3.setVisible(true);
    panelM.setVisible(false);
   }
  });

 }


 public static void main(String[] args) {
  Scanner sc= new Scanner(System.in); //System.in is a standard input stream
  System.out.print("Enter a string: ");
  String str= sc.nextLine();
  new Dashboard(str);
 }
}