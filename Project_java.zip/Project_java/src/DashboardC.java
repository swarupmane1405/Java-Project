import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class DashboardC {
    public DashboardC(String a, String b, String c, String d, String h){
        JFrame F = new JFrame("Dashboard");
        ImageIcon img = new ImageIcon("Employee.png");
        JLabel back = new JLabel("",img,JLabel.CENTER);
        back.setBounds(0,0,1200,650);
        F.setSize(1200,650);
        F.add(back);

        F.setVisible(true);
        F.setResizable(false);
        F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JButton b1 = new JButton("DASHBOARD");
        JButton b2 = new JButton("DOMAINS");
        JButton b3 = new JButton("HIRE");
        JButton b4 = new JButton("MY PROFILE");
        b1.setFont(new Font("Poppins", Font.BOLD, 20));
        b2.setFont(new Font("Poppins", Font.BOLD, 20));
        b3.setFont(new Font("Poppins", Font.BOLD, 20));
        b4.setFont(new Font("Poppins", Font.BOLD, 20));

        b1.setBounds(70, 165, 200, 50);
        back.add(b1);
        b1.setContentAreaFilled(false);
        b1.setBorderPainted(false);
        b1.setForeground(Color.WHITE);

        b2.setBounds(70, 265, 200, 50);
        back.add(b2);
        b2.setContentAreaFilled(false);
        b2.setBorderPainted(false);
        b2.setForeground(Color.WHITE);

        b4.setBounds(70, 465, 200, 50);
        back.add(b4);
        b4.setContentAreaFilled(false);
        b4.setBorderPainted(false);
        b4.setForeground(Color.WHITE);

        b3.setBounds(70, 365, 200, 50);
        back.add(b3);
        b3.setContentAreaFilled(false);
        b3.setBorderPainted(false);
        b3.setForeground(Color.WHITE);

        // dashboard part
        JLabel no_s = new JLabel("Total Students");
        JLabel no_c = new JLabel("Total Companies");
        JLabel no_w = new JLabel("Programs");
        no_s.setFont(new Font("Poppins", Font.BOLD, 20));
        no_c.setFont(new Font("Poppins", Font.BOLD, 20));
        no_w.setFont(new Font("Poppins", Font.BOLD, 20));

        Color my = new Color(0, 156, 200);
        no_s.setForeground(my);
        no_c.setForeground(my);
        no_w.setForeground(my);
        back.add(no_s);
        back.add(no_c);
        back.add(no_w);

        no_s.setBounds(460, 185, 200, 50);
        no_c.setBounds(680, 185, 200, 50);
        no_w.setBounds(960, 185, 200, 50);

        JPanel panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBackground(Color.white);
        panel1.setBounds(350, 0, 850, 650);
        back.add(panel1);
        panel1.setVisible(false);


        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.cyan);
        panel2.setBounds(343, 0, 850, 650);


        JPanel panel3 = new JPanel();
        panel3.setBackground(Color.cyan);
        panel3.setBounds(343, 0, 850, 650);
        back.add(panel3);
        panel3.setVisible(false);
        panel3.setLayout(null);

        JPanel panelM = new JPanel();
        panelM.setBounds(343, 0, 850, 650);
        back.add(panelM);
        panelM.setOpaque(false);
        panelM.setVisible(true);
        panelM.setLayout(null);


        String[] columnNames = {"Company Name", "Department Name","Location"
                , "Requriments","Openings"
        };

        Object[][] data = {
                {"Tcs company","IT Dept","Karad","Designer","5"},
                {"Tcs company","IT Dept","Sangli","Designer","5"},
                {"Tcs company","IT Dept","Satara","Tester","5"},

        };

        JTable table = new JTable(data, columnNames);

        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(120);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(180);
        table.getColumnModel().getColumn(4).setPreferredWidth(120);

        DefaultTableCellRenderer Cell = new DefaultTableCellRenderer();
        Cell.setHorizontalAlignment(JLabel.CENTER);
        for (int i =0; i<5; i++){
            table.getColumnModel().getColumn(i).setCellRenderer(Cell);
        }


        // Dashboard
        JLabel nos = new JLabel();
        nos.setBounds(140,20,100,200);
        nos.setFont(new Font("Poppins", Font.BOLD, 80));
        nos.setForeground(my);
        nos.setText("50");
        panelM.add(nos);

        JLabel noc = new JLabel();
        noc.setBounds(370,20,100,200);
        noc.setFont(new Font("Poppins", Font.BOLD, 80));
        noc.setForeground(my);
        noc.setText("10");
        panelM.add(noc);

        JLabel noj = new JLabel();
        noj.setBounds(610,20,100,200);
        noj.setFont(new Font("Poppins", Font.BOLD, 80));
        noj.setForeground(my);
        noj.setText("06");
        panelM.add(noj);

        JLabel name = new JLabel("<html>Students Hiring System <br><br> This system is for both Student and Companies.<br> The students can apply for the job depending upon their area of expertise and also companies can display the various opening for different domains and also can aprove the proposal from the students.</html>");
        name.setBounds(120,350,650,200);
        panelM.add(name);
        name.setFont(new Font("Poppins", Font.PLAIN, 20));
        name.setForeground(my);

        // Domains


        JLabel Department = new JLabel("Enter Dept : ");
        JLabel Domain = new JLabel("Enter Domain : ");
        JLabel Openings = new JLabel("Enter Openings : ");


        Department.setFont(new Font("Poppins", Font.PLAIN, 20));

        Domain.setFont(new Font("Poppins", Font.PLAIN, 20));
        Openings.setFont(new Font("Poppins", Font.PLAIN, 20));


        Department.setBounds(50,150,300,50);
        Domain.setBounds(50,250,300,50);
        Openings.setBounds(50,350,300,50);


        JTextField Department1 = new JTextField("   Enter Dept ");
        JTextField Domain1 = new JTextField("  Enter Domain");
        JTextField Openings1 = new JTextField("  Enter Openings");



        Department1.setBounds(350,150,300,50);
        Domain1.setBounds(350,250,300,50);
        Openings1.setBounds(350,350,300,50);



        Domain1.setFont(new Font("Poppins", Font.PLAIN, 20));
        Openings1.setFont(new Font("Poppins", Font.PLAIN, 20));

        Department1.setFont(new Font("Poppins", Font.PLAIN, 20));



        Department1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Domain1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Openings1.setBorder(javax.swing.BorderFactory.createEmptyBorder());




        panel1.add(Department);
        panel1.add(Domain);
        panel1.add(Openings);



        panel1.add(Department1);
        panel1.add(Domain1);
        panel1.add(Openings1);


        JButton Apply = new JButton("Update");
        Apply.setFont(new Font("Poppins", Font.PLAIN, 20));
        Apply.setBackground(my);
        Apply.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Apply.setForeground(Color.WHITE);
        Apply.setBounds(350,480,200,50);
        panel1.add(Apply);

        //connectivity

        final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
        final String USERNAME = "root";
        final String PASSWORD = "scm@1405";


        Apply.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {

                                        String studID2 = c;
                                        String UserID2 = b;
                                        String Department2 = Department1.getText();
                                        String AppliedCompany2 = h;
                                        String Domain2 = Domain1.getText();
                                        String Openings2 = Openings1.getText();
                                        String Myuser = a;
                                        String Password = d;

                                        try {
                                            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

                                            Statement stmt = conn.createStatement();
                                            String sql = "INSERT INTO company_info(Comp_Name,Location,Dept_Name,Comp_cont,UserID,Passwd,Domain,Openings)" + "VALUES(?,?,?,?,?,?,?,?)";

                                            PreparedStatement preparedStatement = conn.prepareStatement(sql);
                                            preparedStatement.setString(1, studID2);
                                            preparedStatement.setString(2, UserID2);
                                            preparedStatement.setString(3, Department2);
                                            preparedStatement.setString(4, AppliedCompany2);
                                            preparedStatement.setString(5, Myuser);
                                            preparedStatement.setString(6, Password);
                                            preparedStatement.setString(7, Domain2);
                                            preparedStatement.setString(8, Openings2);

                                            preparedStatement.executeUpdate();

                                            stmt.close();
                                            conn.close();

                                        } catch (Exception z) {
                                            z.printStackTrace();
                                        }

                                    }
                                });

        // Hire
        String[] columnNames1 = null;

        Object[][] data1 = null;

        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdproject", "root", "scm@1405");
            PreparedStatement ps=con.prepareStatement("select Applied_ID,Applied_comp,Approved,Domain,Department,Current_comp from studhireinfo;", ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ResultSet rs=ps.executeQuery();
            ResultSetMetaData rsmd=rs.getMetaData();
            int cols=rsmd.getColumnCount();
            columnNames1=new String[cols];
            for(int i=1;i<=cols;i++){
                columnNames1[i-1]=rsmd.getColumnName(i);
            }
            rs.last();
            int rows=rs.getRow();
            rs.beforeFirst();

            data1=new String[rows][cols];
            int count=0;
            while(rs.next()){
                for(int i=1;i<=cols;i++){
                    data1[count][i-1]=rs.getString(i);
                }
                count++;
            }
            con.close();
        }catch(Exception e){System.out.println(e);}


        JTable table1 = new JTable(data1, columnNames1);

        table1.getColumnModel().getColumn(0).setPreferredWidth(50);
        table1.getColumnModel().getColumn(1).setPreferredWidth(100);
        table1.getColumnModel().getColumn(2).setPreferredWidth(120);
        table1.getColumnModel().getColumn(3).setPreferredWidth(100);
        table1.getColumnModel().getColumn(4).setPreferredWidth(120);
        table1.getColumnModel().getColumn(5).setPreferredWidth(120);


        DefaultTableCellRenderer Cell1 = new DefaultTableCellRenderer();
        Cell1.setHorizontalAlignment(JLabel.CENTER);
        for (int i =0; i<6; i++){
            table1.getColumnModel().getColumn(i).setCellRenderer(Cell1);
        }


        JScrollPane scrollPane1 = new JScrollPane(table1);
        scrollPane1.setViewportView(table1);
        table1.getColumnModel().getColumn(0).setPreferredWidth(200);
        scrollPane1.setBounds(20,20,800,500);
        panel2.add(scrollPane1);

        JTextField searchbar= new JTextField();
        searchbar.setBounds(250, 550, 200,50);
        panel2.add(searchbar);
        JButton selectbtn = new JButton("OK");
        panel2.add(selectbtn);
        selectbtn.setBackground(my);
        selectbtn.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        selectbtn.setBounds(500,550,100,50);
        selectbtn.setForeground(Color.WHITE);

        selectbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ID= searchbar.getText();
                String a =null;
                String b =null;
                String c=null;
                try {
                    Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                    Statement stmt = conn.createStatement();
                    String sql = "UPDATE studhireinfo SET Approved = '1', Current_comp = Applied_comp WHERE Applied_ID='"+ID+"'";
                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.executeUpdate();

                    ResultSet rs = stmt.executeQuery("select * from studhireinfo where Applied_ID ='"+ID+"'");
                   while(rs.next()){
                        a = rs.getString("Applied_comp");
                        b = rs.getString("Department");
                        c= rs.getString("Domain");
                 }

                    String sql1 = "UPDATE company_info SET Openings = Openings-1 WHERE Comp_Name='"+a+"'AND Dept_name='"+b+"'AND Domain='"+c+"'";
                    PreparedStatement preparedStatement1 = conn.prepareStatement(sql1);
                    preparedStatement1.executeUpdate();
                    conn.close();
                }catch(Exception z){System.out.println(e);}
            }
        });

        //profile
        JLabel Myuser = new JLabel();
        JLabel Studname = new JLabel();
        JLabel Gender = new JLabel();
        JLabel dept = new JLabel();

        try{
            Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from company_info where UserID='"+a+"'");
            while(rs.next()){
                Myuser.setText("UserID : "+rs.getString("UserID"));
                Studname.setText("Company Name : "+rs.getString("Comp_name"));
                Gender.setText("Location : "+rs.getString("Location"));
                dept.setText("Contact: "+rs.getString("Comp_cont"));
            }
            stmt.close();
            conn.close();

        }catch (Exception z){
            z.printStackTrace();
        }

        Myuser.setBounds(350,70,400,50);
        Studname.setBounds(350,130,400,50);
        Gender.setBounds(350,190,400,50);
        dept.setBounds(350,250,400,50);

        Myuser.setFont(new Font("Poppins", Font.PLAIN, 20));
        Studname.setFont(new Font("Poppins", Font.PLAIN, 20));
        Gender.setFont(new Font("Poppins", Font.PLAIN, 20));
        dept.setFont(new Font("Poppins", Font.PLAIN, 20));

        panel3.add(Myuser);
        panel3.add(Studname);
        panel3.add(Gender);
        panel3.add(dept);

        ImageIcon profile = new ImageIcon("profilew.png");
        JLabel profilelabel = new JLabel("",profile,JLabel.CENTER);
        profilelabel.setBounds(80,100,200,200);
        panel3.add(profilelabel);

        //button nav

        back.add(panel2);
        panel2.setVisible(false);
        panel2.setLayout(null);
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel1.setVisible(true);
                no_c.setVisible(false);
                no_s.setVisible(false);
                no_w.setVisible(false);
                panel2.setVisible(false);
                panel3.setVisible(false);
                panelM.setVisible(false);
            }
        });
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel1.setVisible(false);
                no_c.setVisible(true);
                no_s.setVisible(true);
                no_w.setVisible(true);
                panel2.setVisible(false);
                panel3.setVisible(false);
                panelM.setVisible(true);
            }
        });

        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel2.setVisible(true);
                no_c.setVisible(false);
                no_s.setVisible(false);
                no_w.setVisible(false);
                panel1.setVisible(false);
                panel3.setVisible(false);
                panelM.setVisible(false);
            }
        });

        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel2.setVisible(false);
                no_c.setVisible(false);
                no_s.setVisible(false);
                no_w.setVisible(false);
                panel1.setVisible(false);
                panel3.setVisible(true);
                panelM.setVisible(false);
            }
        });
    }
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in); //System.in is a standard input stream
        System.out.print("Enter a string: ");
        String str= sc.nextLine();
        String b =null;
        String c =null;
        String d=null;
        String h=null;

        final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
        final String USERNAME = "root";
        final String PASSWORD = "scm@1405";


        try{
            Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from company_info where UserID='"+str+"'");
            while(rs.next()){
                b=rs.getString("Location");
                c =rs.getString("Comp_Name");
                d=rs.getString("Passwd");
                h=rs.getString("Comp_cont");
            }
            stmt.close();
            conn.close();

        }catch (Exception z){
            z.printStackTrace();
        }

      new DashboardC(str,b,c,d,h);
    }
}
