import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class samplecheckbox {
    public samplecheckbox(){
      JFrame f = new JFrame();
      f.setSize(700,700);
      f.setLayout(null);
      JCheckBox a = new JCheckBox("c");
      JCheckBox b = new JCheckBox("Java");
      b.setSelected(true);
      a.setBounds(100,200,100,100);
      b.setBounds(100,300,100,100);
      ButtonGroup bg = new ButtonGroup();
      bg.add(a);
      bg.add(b);
     f.add(a);
     f.add(b);
     f.setVisible(true);

    }

    public static void main(String[] args) {
        new samplecheckbox();
    }
}
