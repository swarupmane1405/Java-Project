import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class LogIn{
    public LogIn() {
        JFrame F = new JFrame("Log In");
        ImageIcon img = new ImageIcon("Log_in.png");
        JLabel back = new JLabel("", img, JLabel.CENTER);
        back.setBounds(0, 0, 800, 500);
        F.setSize(800, 500);
        F.add(back);
        JButton B1 = new JButton("Sign Up");
        JButton B2 = new JButton("Login");
        B1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        B2.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        F.add(B1);
        F.add(B2);
        Color my = new Color(0, 128, 55);

        B1.setBounds(400, 350, 100, 50);
        B2.setBounds(600, 350, 100, 50);
        F.setLayout(null);
        F.setVisible(true);
        F.setResizable(false);
        B1.setBackground(my);
        B2.setBackground(my);
        B1.setForeground(Color.WHITE);
        B2.setForeground(Color.WHITE);
        B1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SignUp S1 = new SignUp();
            }
        });


        JRadioButton Student = new JRadioButton("Student");
        JRadioButton Company = new JRadioButton("Company");
        ButtonGroup bg = new ButtonGroup();
        bg.add(Student);
        bg.add(Company);
        Student.setOpaque(false);
        Student.setFont(new Font("Poppins", Font.PLAIN, 15));
        back.add(Student);
        Company.setOpaque(false);
        back.add(Company);
        Company.setFont(new Font("Poppins", Font.PLAIN, 15));


        Student.setBounds(400, 50, 100, 50);
        Company.setBounds(600, 50, 100, 50);
        JLabel Username = new JLabel("Username : ");
        Username.setBounds(350, 160, 200, 30);
        back.add(Username);
        Username.setFont(new Font("Poppins", Font.BOLD, 18));
        Username.setForeground(my);
        JLabel Password = new JLabel("Password : ");
        Password.setBounds(350, 220, 200, 30);
        Password.setFont(new Font("Poppins", Font.BOLD, 18));
        Password.setForeground(my);
        back.add(Password);


        JTextField txt1 = new JTextField();
        JPasswordField txt2 = new JPasswordField();
        txt1.setBounds(500, 155, 300, 40);
        txt2.setBounds(500, 215, 300, 40);


        txt1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        txt2.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        txt1.setFont(new Font("Poppins", Font.PLAIN, 18));
        txt2.setFont(new Font("Poppins", Font.PLAIN, 18));
        F.add(txt1);
        F.add(txt2);
        txt1.setText("Enter Username");
        txt2.setText("Enter Password");
        F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        B2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String usern = txt1.getText();
                String passn = new String(txt2.getPassword());
                int x;
                if (Student.isSelected()) {
                    x = 10;
                } else {


                    final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
                    final String USERNAME = "root";
                    final String PASSWORD = "scm@1405";

                    String str = usern;
                    String b = null;
                    String c = null;
                    String d = passn;
                    String h = null;


                    try {
                        Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("select * from company_info where UserID='" + str + "'");
                        while (rs.next()) {
                            b = rs.getString("Location");
                            c = rs.getString("Comp_Name");
                            d = rs.getString("Passwd");
                            h = rs.getString("Comp_cont");
                        }
                        stmt.close();
                        conn.close();

                    } catch (Exception z) {
                        z.printStackTrace();
                    }
                    new DashboardC(str, b, c, d, h);
                }
            }
        });
    }
        public static void main(String[] args) {
            new LogIn();
        }
    }

