import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class SignUp {

    public SignUp(){
        JFrame F = new JFrame("Sign Up");
        ImageIcon img = new ImageIcon("Sign_up.png");
        JLabel back = new JLabel("",img,JLabel.CENTER);
        back.setBounds(0,0,800,500);
        F.setSize(800,500);
        F.add(back);
        JButton  B1 = new JButton ("Sign Up");
        JButton  B2 = new JButton ("Login");
        B1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        B2.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        F.add(B1);
        F.add(B2);
        Color my =new Color(79, 25, 100);

        B1.setBounds(400,350,100,50);
        B2.setBounds(600,350, 100, 50);

        B1.setBackground(my);
        B2.setBackground(my);
        B1.setForeground(Color.WHITE);
        B2.setForeground(Color.WHITE);


        JRadioButton Student = new JRadioButton("Student");
        JRadioButton Company = new JRadioButton("Company");
        ButtonGroup bg=new ButtonGroup();
        bg.add(Student);bg.add(Company);
        Student.setOpaque(false);
        Student.setFont(new Font("Poppins", Font.PLAIN, 15));
        back.add(Student);
        Company.setOpaque(false);
        back.add(Company);
        Company.setFont(new Font("Poppins", Font.PLAIN, 15));


        Student.setBounds(400,50, 100, 50);
        Company.setBounds(600,50,100,50);
        JLabel Username = new JLabel("Username : ");
        Username.setBounds(350,160,200, 30);
        back.add(Username);
        Username.setFont(new Font("Poppins", Font.BOLD, 18));
        Username.setForeground(my);
        JLabel Password = new JLabel("Password : ");
        Password.setBounds(350,220, 200, 30);
        Password.setFont(new Font("Poppins", Font.BOLD, 18));
        Password.setForeground(my);
        back.add(Password);


        final JTextField txt1 = new JTextField();
        final JPasswordField txt2 = new JPasswordField();
        txt1.setBounds(500,155, 300, 40);
        txt2.setBounds(500,215, 300, 40);


        txt1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        txt2.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        txt1.setFont(new Font("Poppins", Font.PLAIN, 18));
        txt2.setFont(new Font("Poppins", Font.PLAIN, 18));
        F.add(txt1);
        F.add(txt2);
       txt1.setText("Create Username");
        txt2.setText("Create Password");



        B2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LogIn l1=new LogIn();
            }
        });
        B1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usern = txt1.getText();
                String passn = new String(txt2.getPassword());


                if (usern.isEmpty() || passn.isEmpty()){
                    Retry r1 = new Retry();
                }
                else{
                    if (Student.isSelected()){
                        new Info(usern,passn);
                    }else {

                        new Infoc(usern,passn);
                    }
                }
            }
        });

        F.setLayout(null);
        F.setVisible(true);
        F.setResizable(false);
        F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public static void main(String[] args) {
       new SignUp();
    }
}
