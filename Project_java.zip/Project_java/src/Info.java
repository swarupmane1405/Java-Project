import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class Info {
   public Info(String k, String g){

       JFrame Info = new JFrame("Info");
       Info.setSize(850,550);


       Color my = new Color(200, 0, 0);


       JPanel panel2 = new JPanel();
       panel2.setBackground(Color.PINK);
       panel2.setBounds(343, 0, 850, 550);

       panel2.setVisible(true);
       panel2.setLayout(null);

       JLabel StudID = new JLabel("Enter Student Name : ");
       JLabel UserID = new JLabel("Enter Gender : ");
       JLabel Department = new JLabel("Enter Department : ");
       JLabel AppliedCompany = new JLabel("Enter Institute Name : ");



       StudID.setFont(new Font("Poppins", Font.PLAIN, 20));
       UserID.setFont(new Font("Poppins", Font.PLAIN, 20));
       Department.setFont(new Font("Poppins", Font.PLAIN, 20));
       AppliedCompany.setFont(new Font("Poppins", Font.PLAIN, 20));

       StudID.setBounds(50,100,300,50);
       UserID.setBounds(50,160,300,50);
       Department.setBounds(50,220,300,50);
       AppliedCompany.setBounds(50,280,300,50);


       JTextField StudID1 = new JTextField(" Enter Student Name");
       String[] choices1 = { "Male","Female"};
       final JComboBox<String> UserID1 = new JComboBox<String>(choices1);
       JTextField Department1 = new JTextField("   Enter Department");
       JTextField AppliedCompany1 = new JTextField("  Enter Institute Name");

       StudID1.setBounds(350,100,400,50);
       UserID1.setBounds(350,160,400,50);
       Department1.setBounds(350,220,400,50);
       AppliedCompany1.setBounds(350,280,400,50);


       StudID1.setFont(new Font("Poppins", Font.PLAIN, 20));
       UserID1.setFont(new Font("Poppins", Font.PLAIN, 20));
       Department1.setFont(new Font("Poppins", Font.PLAIN, 20));
       AppliedCompany1.setFont(new Font("Poppins", Font.PLAIN, 20));

        UserID1.setBackground(Color.white);
       StudID1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       UserID1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       Department1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       AppliedCompany1.setBorder(javax.swing.BorderFactory.createEmptyBorder());


       panel2.add(StudID);
       panel2.add(UserID);
       panel2.add(Department);
       panel2.add(AppliedCompany);


       panel2.add(StudID1);
       panel2.add(UserID1);
       panel2.add(Department1);
       panel2.add(AppliedCompany1);


       JButton Apply = new JButton("Proceed");
       Apply.setFont(new Font("Poppins", Font.PLAIN, 20));
       Apply.setBackground(my);
       Apply.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       Apply.setForeground(Color.WHITE);
       Apply.setBounds(350,350,200,50);
       panel2.add(Apply);

       //connectivity

       final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
       final String USERNAME = "root";
       final String PASSWORD = "scm@1405";


       Apply.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               new Dashboard(k);

               String studID2 = StudID1.getText();
               String UserID2 = UserID1.getSelectedItem().toString();
               String Department2 = Department1.getText();
               String AppliedCompany2 = AppliedCompany1.getText();
               String Myuser = k;
               String Password = g;

               try{
                   Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);

                   Statement stmt = conn.createStatement();
                   String sql = "INSERT INTO studperinfo(Stud_name,Gender,Department,InstituteName,UserID,Passwd)"+"VALUES(?,?,?,?,?,?)";

                   PreparedStatement preparedStatement = conn.prepareStatement(sql);
                   preparedStatement.setString(1, studID2);
                   preparedStatement.setString(2,UserID2);
                   preparedStatement.setString(3,Department2);
                   preparedStatement.setString(4,AppliedCompany2);
                   preparedStatement.setString(5,Myuser);
                   preparedStatement.setString(6,Password);

                   preparedStatement.executeUpdate();

                   stmt.close();
                   conn.close();

               }catch (Exception z){
                   z.printStackTrace();
               }

           }
       });

       Info.add(panel2);
       Info.setVisible(true);
       Info.setResizable(false);
       Info.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

   }

    public static void main(String[] args) {
       new Info("helo1","myname");

    }
}
