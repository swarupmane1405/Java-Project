import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class Pop {
    public Pop(int x){
        JFrame pop1 = new JFrame("Succefull !!");
        JPanel pop = new JPanel();
        pop1.add(pop);
        pop.setSize(300,100);
        pop1.setBounds(100,100,300,100);
        JLabel l1 = new JLabel("Click ok to proceed Further : ");
        l1.setBounds(20,50,200,100);
        pop.add(l1);
        JButton click = new JButton("OK");
        click.setBounds(220,50,100,100);
        pop.add(click);
        pop1.setVisible(true);
        pop1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        click.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(x==10){
                    Dashboard d1 = new Dashboard("scm1405");
                }
                else {
                    DashboardC d2 = new DashboardC("a","b","c","d","h");
                }
            }
        });
}

    public static void main(String[] args) {
        new Pop(10);
    }
}
