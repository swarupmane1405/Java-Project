import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.colorchooser.ColorSelectionModel;

public class Infoc {
    public Infoc(String k, String g){
        JFrame Info = new JFrame("Info");
        Info.setSize(850,550);


        Color my = new Color(0, 156, 200);


        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.CYAN);
        panel2.setBounds(343, 0, 850, 550);

        panel2.setVisible(true);
        panel2.setLayout(null);

        JLabel StudID = new JLabel("Enter Company Name : ");
        JLabel UserID = new JLabel("Enter Location : ");
        JLabel Department = new JLabel("Enter Dept : ");
        JLabel AppliedCompany = new JLabel("Enter Contact no : ");
        JLabel Domain = new JLabel("Enter Domain : ");
        JLabel Openings = new JLabel("Enter Openings : ");

        StudID.setFont(new Font("Poppins", Font.PLAIN, 20));
        UserID.setFont(new Font("Poppins", Font.PLAIN, 20));
        Department.setFont(new Font("Poppins", Font.PLAIN, 20));
        AppliedCompany.setFont(new Font("Poppins", Font.PLAIN, 20));
        Domain.setFont(new Font("Poppins", Font.PLAIN, 20));
        Openings.setFont(new Font("Poppins", Font.PLAIN, 20));

        StudID.setBounds(50,50,300,50);
        UserID.setBounds(50,110,300,50);
        Department.setBounds(50,170,300,50);
        AppliedCompany.setBounds(50,230,300,50);
        Domain.setBounds(50,290,300,50);
        Openings.setBounds(50,350,300,50);

        JTextField StudID1 = new JTextField("   Enter Company Name");
        JTextField UserID1 = new JTextField("   Enter Location ");
        JTextField Department1 = new JTextField("   Enter Dept ");
        JTextField AppliedCompany1 = new JTextField("  Enter Contact no");
        JTextField Domain1 = new JTextField("  Enter Domain");
        JTextField Openings1 = new JTextField("  Enter Openings");


        StudID1.setBounds(350,50,300,50);
        UserID1.setBounds(350,110,300,50);
        Department1.setBounds(350,170,300,50);
        AppliedCompany1.setBounds(350,230,300,50);
        Domain1.setBounds(350,290,300,50);
        Openings1.setBounds(350,350,300,50);



        Domain1.setFont(new Font("Poppins", Font.PLAIN, 20));
        Openings1.setFont(new Font("Poppins", Font.PLAIN, 20));
        StudID1.setFont(new Font("Poppins", Font.PLAIN, 20));
        UserID1.setFont(new Font("Poppins", Font.PLAIN, 20));
        Department1.setFont(new Font("Poppins", Font.PLAIN, 20));
        AppliedCompany1.setFont(new Font("Poppins", Font.PLAIN, 20));


        StudID1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        UserID1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Department1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        AppliedCompany1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Domain1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Openings1.setBorder(javax.swing.BorderFactory.createEmptyBorder());



        panel2.add(StudID);
        panel2.add(UserID);
        panel2.add(Department);
        panel2.add(AppliedCompany);
        panel2.add(Domain);
        panel2.add(Openings);


        panel2.add(StudID1);
        panel2.add(UserID1);
        panel2.add(Department1);
        panel2.add(AppliedCompany1);
        panel2.add(Domain1);
        panel2.add(Openings1);


        JButton Apply = new JButton("Proceed");
        Apply.setFont(new Font("Poppins", Font.PLAIN, 20));
        Apply.setBackground(my);
        Apply.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        Apply.setForeground(Color.WHITE);
        Apply.setBounds(350,420,200,50);
        panel2.add(Apply);

        //connectivity

        final String DB_URL = "jdbc:mysql://localhost:3306/jdproject";
        final String USERNAME = "root";
        final String PASSWORD = "scm@1405";


        Apply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String studID2 = StudID1.getText();
                String UserID2 = UserID1.getText();
                String Department2 = Department1.getText();
                String AppliedCompany2 = AppliedCompany1.getText();
                String Domain2 = Domain1.getText();
                String Openings2 = Openings1.getText();
                String Myuser = k;
                String Password = g;

                new DashboardC(studID2,UserID2,k,g,AppliedCompany2);


                try{
                    Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);

                    Statement stmt = conn.createStatement();
                    String sql = "INSERT INTO company_info(Comp_Name,Location,Dept_Name,Comp_cont,UserID,Passwd,Domain,Openings)"+"VALUES(?,?,?,?,?,?,?,?)";

                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.setString(1, studID2);
                    preparedStatement.setString(2,UserID2);
                    preparedStatement.setString(3,Department2);
                    preparedStatement.setString(4,AppliedCompany2);
                    preparedStatement.setString(5,Myuser);
                    preparedStatement.setString(6,Password);
                    preparedStatement.setString(7,Domain2);
                    preparedStatement.setString(8,Openings2);

                    preparedStatement.executeUpdate();
                    preparedStatement.execute("select * from company_info");
                    stmt.close();
                    conn.close();

                }catch (Exception z){
                    z.printStackTrace();
                }

            }
        });

        Info.add(panel2);
        Info.setVisible(true);
        Info.setResizable(false);
        Info.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main(String[] args) {
        new Infoc("helo","myname");
    }
}
